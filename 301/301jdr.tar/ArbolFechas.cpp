#include "ArbolFechas.h"
#include <algorithm>
#include <iostream>

using namespace std;

ArbolFechas::ArbolFechas() : raiz(nullptr) {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
}

ArbolFechas::~ArbolFechas() {
    destruir_recursivo(raiz);
}

void ArbolFechas::destruir_recursivo(Nodo* nodo) {
    if (nodo) {
        destruir_recursivo(nodo->izq);
        destruir_recursivo(nodo->der);
        delete nodo;
    }
}

void ArbolFechas::insertar(const Cuac* c) {
    insertar_recursivo(raiz, c);
}

void ArbolFechas::insertar_recursivo(Nodo*& nodo, const Cuac* c) {
    if (!nodo) {
        nodo = new Nodo(c);
        return;
    }
    if (*c < *nodo->dato) {
        insertar_recursivo(nodo->izq, c);
    } else {
        insertar_recursivo(nodo->der, c);
    }
}

vector<const Cuac*> ArbolFechas::ultimos(int n) const {
    vector<const Cuac*> lista;
    if (n > 0) {
        lista.reserve(n); 
        int contador = n;
        ultimos_recursivo(raiz, lista, contador);
    }
    return lista;
}

void ArbolFechas::ultimos_recursivo(Nodo* nodo, vector<const Cuac*>& lista, int& n) const {
    if (!nodo || n <= 0) return;

    ultimos_recursivo(nodo->izq, lista, n);

    if (n > 0) {
        lista.push_back(nodo->dato);
        n--;
    } else {
        return;
    }

    if (n > 0) {
        ultimos_recursivo(nodo->der, lista, n);
    }
}

vector<const Cuac*> ArbolFechas::buscar_rango(const Fecha& inicio, const Fecha& fin) const {
    vector<const Cuac*> lista;
    buscar_rango_recursivo(raiz, inicio, fin, lista);
    return lista;
}

void ArbolFechas::buscar_rango_recursivo(Nodo* nodo, const Fecha& inicio, const Fecha& fin, vector<const Cuac*>& lista) const {
    if (!nodo) return;

    const Fecha& f_nodo = nodo->dato->get_fecha();
    
    bool nodo_es_muy_nuevo = fin.es_menor(f_nodo);
    
    if (!nodo_es_muy_nuevo) {
        buscar_rango_recursivo(nodo->izq, inicio, fin, lista);
    }
    
    bool nodo_es_muy_viejo = f_nodo.es_menor(inicio);

    if (!nodo_es_muy_nuevo && !nodo_es_muy_viejo) {
        lista.push_back(nodo->dato);
    }
    
    if (!nodo_es_muy_viejo) {
        buscar_rango_recursivo(nodo->der, inicio, fin, lista);
    }
}